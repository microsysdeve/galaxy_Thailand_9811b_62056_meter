//RTC�¶�����Kϵ��
__root const uint8 code InitParaRTC[]@0xD00=
{
    0xE5,0x03,	//0.997 
    0xE8,0x03,	//1.000 
    0xEC,0x03,	//1.004 
    0xEF,0x03,	//1.007 
    0xD9,0x03,	//0.985 
    0xDC,0x03,	//0.988 
    0xE0,0x03,	//0.992 
    0xE3,0x03,	//0.995 
    0xD3,0x03,	//0.979 
    0xD6,0x03,	//0.982 
    0xD9,0x03,	//0.985 
    0xDC,0x03,	//0.988 
    0xC6,0x03,	//0.966 
    0xC9,0x03,	//0.969 
    0xCC,0x03,	//0.972 
    0xCF,0x03,	//0.975 
    0x10,0x04,	//1.040 
    0x13,0x04,	//1.043 
    0x16,0x04,	//1.046 
    0x19,0x04,	//1.049 
    0x03,0x04,	//1.027 
    0x07,0x04,	//1.031 
    0x0A,0x04,	//1.034 
    0x0D,0x04,	//1.037 
    0xFA,0x03,	//1.018 
    0xFD,0x03,	//1.021 
    0x00,0x04,	//1.024 
    0x03,0x04,	//1.027 
    0xED,0x03,	//1.005 
    0xF1,0x03,	//1.009 
    0xF4,0x03,	//1.012 
    0xF7,0x03,	//1.015 
};




/*=========================================================================================\n
* @function_name: Correct_Rtc
* @function_file: RtcCpt.c
* @����: У��RTC
*
*
* @����:
* @param:Hvalue
* @param:Lvalue
* @����:
* @����:   lwb (2012-03-24)
* @��ע:
*-------------------------------------------------------------------------------------------
* @�޸���:
* @�޸�����:
===========================================================================================*/
void SetRTCNormal(int16 offset)
{
    Word32 temp1,temp2;
    int16 temp3;
    temp2.lword=0;
    temp1.lword=(uint16)offset;
    if((temp1.byte[1]>0x80))                                 //����THֵ
    { 
        temp1.word[0]=(~temp1.word[0]);
        temp1.word[0]&=0x1fff;
        temp1.lword=temp1.lword*20/30;                      //����ƫ�ƾ���Ϊ0.1ppm
        temp2.lword=6553600-1;
        temp2.lword=temp2.lword+temp1.lword;
    }
    else
    {
        temp1.lword=(temp1.lword)*20/30;
        temp2.lword=6553600;
        temp2.lword=temp2.lword-temp1.lword;
    }
    temp3=offset/10;                                       //����Cֵ
    temp1.lword=(uint16)temp3;
    RTCPEN=0x96;                      
    RTCPWD=0x57;
    DelayOSC(5);
    RTCCH=temp1.byte[1];                                   //д��Cֵ��THֵ
    RTCCL=temp1.byte[0];
    DIVTHH=temp2.byte[2];
    DIVTHM=temp2.byte[1];
    DIVTHL=temp2.byte[0];
    DelayOSC(5);
    RTCPEN=0x96;
    RTCPWD=0x56;
}
//extern const uint8 code InitParaRTC[];
/*=========================================================================================\n
* @function_name: CalRTC
* @function_file: RtcCpt.h
* @����: ����RTCƫ��ppm
*
* @����:
* @����:
* @����:   lwb (2012-03-22)
* @��ע:
*-------------------------------------------------------------------------------------------
* @�޸���:
* @�޸�����:
===========================================================================================*/
void CalRTC(void)
{
    uint8 ucdata[4];
    Word32 temp1;
    int32 delta;
    float temperature; //��ǰ�¶�
    int8  tempoffset;
    int16  OSC;
    uint32 BparaTemp[5];
    int32 Bpara;
    uint32  MAdcValue;
    uint8 Ti;
    uint32  temp;
    S_TEMPPARA s_TempPara;
    S_BPARATEMP s_BparaTemp;
    uint8 code *p;
    uint8 TempParaSum;
    uint8 i;

    p=(uint8 code*)0x420;
    for(uint8 i=0;i<3;i++)
    {
        FCpyTMem((uint8*)&s_TempPara.ul_TempParaA,p+i*24,sizeof(S_TEMPPARA));
        TempParaSum=DoSum((uint8*)&s_TempPara.ul_TempParaA,sizeof(S_TEMPPARA)-2)+0x33;
        if(TempParaSum==s_TempPara.uc_Add33)
        {
            break;
        }
    }

    //==========================================================================��ʼ�����¶�ֵ
   
    MAdcValue=EnyB_ReadMeterParaACK(DATAOM);                         //��Mͨ��ԭʼֵ
 
    

    temp=MAdcValue>>16;
    FCpyTMem((uint8 *)&gui_Kpara, (uint8 code*)&InitParaRTC[(CtrlBGP&0x3e)], 0x02);     //��ȡkֵ
    temp=(temp*gui_Kpara)/1000;

    
    if(TempParaSum!=s_TempPara.uc_Add33)                                       //��������£��¶����߲�����Flash�л�ȡ�����û������ݲ�ͬоƬ���Ͳ���Ĭ�ϲ���ֵ
    {        
        s_TempPara.ul_TempParaA = 18018;
        s_TempPara.ul_TempParaB = 1;
        s_TempPara.ul_TempParaC = 224019254;
        s_TempPara.ul_TempParaD = 7092;
        s_TempPara.ul_TempParaE = 10;
    }
//============================================================================�����¶�
    temperature=(s_TempPara.ul_TempParaB*sqrt(s_TempPara.ul_TempParaC+s_TempPara.ul_TempParaD*temp)-s_TempPara.ul_TempParaA)/s_TempPara.ul_TempParaE;
    

    BE_ReadP(EEP_RTCTEMPOFFSET,(uint8*)&tempoffset,1);                       //  ��ȡ�¶ȳ���ƫ�ƣ���ֵ��ΪУ���������ڴ�������

    temperature+=tempoffset;                                                 // �¶�ƫ��У��                                              
#ifndef V98xxS/A                                                             //�����V98XXϵ�У������߻��Ѳ���ʱ����Ҫ����������
    if(_SYS_IS_PWR_OFF)
    {
        temperature-=6;
    }
#endif
    if(temperature>90)
    {   
        temperature=90;
    }else if(temperature<(-43))
    {   
        temperature=-43;
    }

    gi_Temprature=(uint16)(temperature*10);                                   //�����¶ȵ�ȫ�ֱ�����
    
    //=======================================================================��ȡRTC ��Bpara����ֵ
    p=(uint8 code*)0x498;
    for(i=0;i<3;i++)
    {
        FCpyTMem((uint8*)&s_BparaTemp.ul_BparaTemp1,p+i*22,sizeof(S_BPARATEMP));
        if(s_BparaTemp.ul_BparaTemp1 != 0xFFFFFFFF)
        {
            break;
        }
    }
    if(i == 3)
    {
      BE_ReadP(EEP_RTCBVAL, (uint8*)BparaTemp,20);                                         //RTCBֵ
    }
    else
    {
      for(i=0;i<5;i++)   //��С�˻���
      {
        MemInvertCpy( (uint8*)BparaTemp +i*4,(uint8*)&s_BparaTemp.ul_BparaTemp1 +i*4,4);
      }
    }
 //==========================================================================�����¶�ֵ����ȡ��ͬ��Bpara����
    if(temperature>=50)
    {
      Bpara=BparaTemp[4];
    }
    else if((temperature<50)&&(temperature>=40))
    {
        Bpara=BparaTemp[3];
    }
    else if((temperature<40)&&(temperature>=0))
    {
        Bpara=BparaTemp[2];
    }
    else if((temperature<0)&&(temperature>=-20))
    {
        Bpara=BparaTemp[1];
    }
    else if(temperature<-20)
    {
        Bpara=BparaTemp[0];
    }

    
    BE_ReadP(EEP_RTCDDTEMP, (uint8*)&Ti,1);                                  //��ȡ�����¶�

   
    BE_ReadP(EEP_RTCFRQOFFSET, (uint8*)ucdata,4);                            // ��ȡRTC����ƫ��
 
    MemInvertCpy(temp1.byte,ucdata,4);
     
    delta=(int32)temp1.lword;
//===========================================================================���㣨C-1��X10��ֵ
    OSC=(int16)((((float)Bpara)*(temperature-((float)Ti))*(temperature-((float)Ti)))/1000000+delta);

    SetRTCNormal(OSC);                                                       // ���ú�������TH��Cֵ
}
